<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>4KHDHub - High Quality Movies and TV Shows</title>
  
  <script>
    !function(){try{"light"===localStorage.getItem("theme")?(document.documentElement.classList.remove("dark"),document.documentElement.classList.add("light")):(document.documentElement.classList.add("dark"),document.documentElement.classList.remove("light"))}catch(e){console.error("Theme initialization failed:",e)}}();
  </script>
  

  <meta name="description" content="Explore high quality movies and TV shows in UHD, 4K HDR, 1080p and more formats">
  <meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1">
  <link rel="canonical" href="https://4khdhub.one/index.php">
      <link rel="next" href="https://4khdhub.one/index.php?pagex=2">
  
  <meta property="og:locale" content="en_US">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="4KHDHub">
  <meta property="og:title" content="4KHDHub - High Quality Movies and TV Shows">
  <meta property="og:description" content="Explore high quality movies and TV shows in UHD, 4K HDR, 1080p and more formats">
  <meta property="og:url" content="https://4khdhub.one/index.php">
  <meta property="og:image" content="https://4khdhub.one/images/4KHDHUB-Dark-Logo.png">

  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="4KHDHub - High Quality Movies and TV Shows">
  <meta name="twitter:description" content="Explore high quality movies and TV shows in UHD, 4K HDR, 1080p and more formats">
  <meta name="twitter:image" content="https://4khdhub.one/images/4KHDHUB-Dark-Logo.png">
  
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">


  <link rel="preload" href="/images/4KHDHUB-Dark-Logo.png" as="image" type="image/png" />
  <link rel="preload" href="/images/4KHDHUB-Bright-Logo.png" as="image" type="image/png" />
  
<script async data-cfasync="false" data-clocid="2145878" src="//renamereptiliantrance.com/on.js"></script>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link href="https://fonts.cdnfonts.com/css/trebuchet-ms-2" rel="stylesheet">

<link rel="stylesheet" href="/css/styles.css?v=0.15.69g27">
  
<link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
<meta name="apple-mobile-web-app-title" content="4K-HDHub" />
<link rel="manifest" href="/site.webmanifest" /> 

<script type="text/javascript">
!function(e,n,t){"use strict";var o="https://fonts.googleapis.com/css?family=Open+Sans",r="__3perf_googleFonts_5fd56";function c(e){(n.head||n.body).appendChild(e)}function a(){var e=n.createElement("link");e.href=o,e.rel="stylesheet",c(e)}function f(e){if(!n.getElementById(r)){var t=n.createElement("style");t.id=r,c(t)}n.getElementById(r).innerHTML=e}e.FontFace&&e.FontFace.prototype.hasOwnProperty("display")?(t[r]&&f(t[r]),fetch(o).then(function(e){return e.text()}).then(function(e){return e.replace(/@font-face {/g,"@font-face{font-display:swap;")}).then(function(e){return t[r]=e}).then(f).catch(a)):a()}(window,document,localStorage);
</script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-LL0RL7VX47"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-LL0RL7VX47');
</script>
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"WebSite","name":"4KHDHub","url":"https://4khdhub.one/","potentialAction":{"@type":"SearchAction","target":"https://4khdhub.one/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>

<!-- Quality Badges Styles -->
<style>
.quality-badges {
    position: absolute;
    top: 6px;
    right: 6px;
    display: flex;
    flex-direction: row;
    gap: 3px;
    z-index: 10;
    flex-wrap: wrap;
    justify-content: flex-end;
    max-width: 85%;
}

.quality-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 2px 5px;
    border-radius: 2px;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.3px;
    line-height: 1;
    text-transform: uppercase;
    backdrop-filter: blur(4px);
    transition: all 0.15s ease;
}

/* 4K - Orange/Gold premium */
.badge-4k {
    background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
    color: #000;
    border: 1px solid rgba(251, 191, 36, 0.5);
    box-shadow: 0 1px 3px rgba(217, 119, 6, 0.5);
}

/* FHD - Muted dark */
.badge-fhd {
    background: rgba(40, 40, 50, 0.9);
    color: rgba(255, 255, 255, 0.8);
    border: 1px solid rgba(255, 255, 255, 0.12);
}

/* HDR - Red/Orange warm */
.badge-hdr {
    background: linear-gradient(135deg, #b91c1c 0%, #dc2626 100%);
    color: #fff;
    border: 1px solid rgba(220, 38, 38, 0.4);
    box-shadow: 0 1px 3px rgba(185, 28, 28, 0.4);
}

/* DV - Black with white text (Dolby style) */
.badge-dv {
    background: #000;
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.3);
    padding: 2px 4px;
}

/* BD - Blue */
.badge-bd {
    background: linear-gradient(135deg, #1d4ed8 0%, #3b82f6 100%);
    color: #fff;
    border: 1px solid rgba(59, 130, 246, 0.4);
    box-shadow: 0 1px 3px rgba(29, 78, 216, 0.4);
}

/* REMUX - Purple */
.badge-remux {
    background: linear-gradient(135deg, #6b21a8 0%, #9333ea 100%);
    color: #fff;
    border: 1px solid rgba(147, 51, 234, 0.4);
    box-shadow: 0 1px 3px rgba(107, 33, 168, 0.4);
}
/* IMAX - Signature blue with premium feel */
.badge-imax {
    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
    color: #fff;
    border: 1px solid rgba(37, 99, 235, 0.5);
    box-shadow: 0 1px 3px rgba(30, 58, 95, 0.5);
    font-weight: 800;
    letter-spacing: 0.5px;
}

.quality-badge:hover {
    transform: translateY(-1px);
    filter: brightness(1.1);
}
</style>

</head>
<body>
<div class="flex min-h-screen flex-col">
  <header class="sticky top-0 z-50 w-full">
    <div class="header">
      <div class="container flex h-14 items-center justify-between">
        <!-- Logo and mobile menu toggle -->
        <div class="flex items-center">
          <button id="menu-toggle" class="menu-toggle md:hidden">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5">
              <line x1="3" y1="12" x2="21" y2="12"></line>
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
            <span class="sr-only">Toggle menu</span>
          </button>
          <a href="/" class="navbar-brand" data-no-swup aria-label="4KHDHub Home">
            <img id="logo" class="h-8 w-auto" src="/images/4KHDHUB-Bright-Logo.png" alt="4KHDHub logo">
          </a>
        </div>

        <!-- SINGLE Navigation - Visible on desktop, hidden on mobile -->
        <nav id="main-nav" class="main-nav">
          <ul class="nav-list">
            <li class="nav-item"><a href="/" class="nav-link" data-no-swup>Home</a></li>
            
            <li class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle">
                Movies
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dropdown-indicator h-4 w-4">
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </a>
              <ul class="dropdown-menu">
                <li><a href="/category/movies/" class="dropdown-item">Latest Movies</a></li>
                <li><a href="/category/hindi-movies/" class="dropdown-item">Hindi Movies</a></li>
                <li><a href="/category/english-movies/" class="dropdown-item">English Movies</a></li>
              </ul>
            </li>
            
            <li class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle">
                Web Series
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dropdown-indicator h-4 w-4">
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </a>
              <ul class="dropdown-menu">
                <li><a href="/category/series/" class="dropdown-item">Latest Episodes</a></li>
                <li><a href="/category/korean-series/" class="dropdown-item">Korean</a></li>
                <li><a href="/category/drama-series/" class="dropdown-item">Drama</a></li>
                <li><a href="/category/hindi-series/" class="dropdown-item">Hindi Series</a></li>
                <li><a href="/category/english-series/" class="dropdown-item">English Series</a></li>
                
              </ul>
            </li>
            
            <li class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle">
                OTT
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dropdown-indicator h-4 w-4">
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </a>
              <ul class="dropdown-menu">
                <li><a href="/category/netflix/" class="dropdown-item">Netflix</a></li>
                <li><a href="/category/amazon_prime_video/" class="dropdown-item">Amazon Prime Video</a></li>
                <li><a href="/category/jiohotstar/" class="dropdown-item">JioHotstar</a></li>
                <li><a href="/category/disney/" class="dropdown-item">Disney+</a></li>
                <li><a href="/category/apple_tv/" class="dropdown-item">Apple TV+</a></li>
                <li><a href="/category/hbo_max/" class="dropdown-item">HBO Max</a></li>
                <li><a href="/category/hulu/" class="dropdown-item">Hulu</a></li>
                <li><a href="/category/crave/" class="dropdown-item">Crave</a></li>
                
              </ul>
            </li>
            
            
            <li class="nav-item"><a href="/category/anime/" class="nav-link">Anime</a></li>
            <li class="nav-item"><a href="/category/2160p-HDR/" class="nav-link">4K HDR</a></li>
            <li class="nav-item"><a href="/category/imdb/" class="nav-link">Top IMdb</a></li>
            
          </ul>
        </nav>

        <!-- Search and Theme Toggle -->
        <div class="flex items-center">
          <button id="search-toggle" class="search-toggle">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <span class="sr-only">Search</span>
          </button>
          
          <div class="search-container hidden md:flex">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="search-icon h-4 w-4">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            for
            <input type="search" id="search" placeholder="Search movies & series" class="search-input">
          </div>
          
          <button id="theme-toggle" class="theme-toggle">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="theme-icon h-5 w-5">
              <circle cx="12" cy="12" r="5"></circle>
              <line x1="12" y1="1" x2="12" y2="3"></line>
              <line x1="12" y1="21" x2="12" y2="23"></line>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
              <line x1="1" y1="12" x2="3" y2="12"></line>
              <line x1="21" y1="12" x2="23" y2="12"></line>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
            </svg>
            <span class="sr-only">Toggle theme</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Mobile Menu Backdrop (only shown when menu is open) -->
    <div id="mobile-menu-backdrop" class="fixed inset-0 bg-black/70 hidden"></div>

    <!-- Close button for mobile menu (only shown when menu is open) -->
    <button id="close-mobile-menu" class="fixed top-4 right-4 p-2 rounded-full z-[60] hidden">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>

    <!-- Search Overlay -->
    <div id="search-overlay" class="fixed inset-0 z-50 hidden">
      <div class="fixed" id="search-backdrop"></div>
      
      
      <button id="close-search" class="absolute right-4 top-4 p-2 rounded-full">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
        <span class="sr-only">Close</span>
      </button>
      
      <form action="/" method="get" class="search-form">
        <div class="search-input-container">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="search-icon-overlay">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <input type="search" name="s" placeholder="Search Movies & TV-Shows" class="search-input-overlay" autofocus autocomplete="off">
        </div>
        <button type="submit" class="search-submit">
          Search
        </button>
      </form>
    </div>
  </header>

  <div id="swup" class="transition-fade flex flex-1 flex-col w-full">
  <main class="flex-1">
    <div class="container">
      <section class="latest-releases">
        <div class="latest-releases-header">
          <h2 class="latest-releases-title">
          <span><svg style="vertical-align: bottom;" xmlns="http://www.w3.org/2000/svg" height="32px" viewBox="0 -960 960 960" width="32px" fill="#e3e3e3"><path d="M240-400q0 52 21 98.5t60 81.5q-1-5-1-9v-9q0-32 12-60t35-51l113-111 113 111q23 23 35 51t12 60v9q0 4-1 9 39-35 60-81.5t21-98.5q0-50-18.5-94.5T648-574q-20 13-42 19.5t-45 6.5q-62 0-107.5-41T401-690q-39 33-69 68.5t-50.5 72Q261-513 250.5-475T240-400Zm240 52-57 56q-11 11-17 25t-6 29q0 32 23.5 55t56.5 23q33 0 56.5-23t23.5-55q0-16-6-29.5T537-292l-57-56Zm0-492v132q0 34 23.5 57t57.5 23q18 0 33.5-7.5T622-658l18-22q74 42 117 117t43 163q0 134-93 227T480-80q-134 0-227-93t-93-227q0-129 86.5-245T480-840Z"/></svg></span> Latest Releases          </h2>
          
        </div>
        
        <div class="card-grid">
                    
                    <a href="/mobland-series-98/" class="movie-card" aria-label="MobLand details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/abeH7n5pcuQcwYcTxG6DTZvXLP1.jpg" alt="MobLand" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Drama</span>
                  
                                    <span class="movie-card-format">Crime</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">Dual Language</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">MobLand</h3>
              <p class="movie-card-meta">2025              • S01-S02 EP02              </p>
            </div>
          </a>
          
          
                    
                    <a href="/unabomber-movie-8202/" class="movie-card" aria-label="UNABOMBER details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/yXbG3BjBlu79tIknvqOF5Pnkw1V.jpg" alt="UNABOMBER" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">History</span>
                  
                                    <span class="movie-card-format">Thriller</span>
                  
                                    <span class="movie-card-format">Crime</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Netflix</span>
                  
                                    <span class="movie-card-format">Tamil</span>
                  
                                    <span class="movie-card-format">Movies</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">Telugu</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">UNABOMBER</h3>
              <p class="movie-card-meta">2026                            </p>
            </div>
          </a>
          
          
                    
                    <a href="/the-final-problem-series-8203/" class="movie-card" aria-label="The Final Problem details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/vIiBBq2yelS3HuBA8uRM83ug2vb.jpg" alt="The Final Problem" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">Crime</span>
                  
                                    <span class="movie-card-format">Drama</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">History</span>
                  
                                    <span class="movie-card-format">Mystery</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">Spanish</span>
                  
                                    <span class="movie-card-format">Tamil</span>
                  
                                    <span class="movie-card-format">Telugu</span>
                  
                                    <span class="movie-card-format">Thriller</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">The Final Problem</h3>
              <p class="movie-card-meta">2026              • S01              </p>
            </div>
          </a>
          
          
                    
                    <a href="/a-different-world-series-8184/" class="movie-card" aria-label="A Different World details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/mmE4RNbsPOwwRo5rnVRd1IXzgcZ.jpg" alt="A Different World" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Drama</span>
                  
                                    <span class="movie-card-format">Comedy</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Netflix</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">A Different World</h3>
              <p class="movie-card-meta">2026              • S01              </p>
            </div>
          </a>
          
          
                    
                    <a href="/toy-story-5-movie-8178/" class="movie-card" aria-label="Toy Story 5 details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span><span class="quality-badge badge-bd" title="Blu-ray">BD</span></div>              <img src="https://image.tmdb.org/t/p/w500/sfQtVlIHljToOwYjhe21KPGzZWK.jpg" alt="Toy Story 5" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">Adventure</span>
                  
                                    <span class="movie-card-format">Animation</span>
                  
                                    <span class="movie-card-format">BluRay</span>
                  
                                    <span class="movie-card-format">Comedy</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">Family</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">Movies</span>
                  
                                    <span class="movie-card-format">Multi Audios</span>
                  
                                    <span class="movie-card-format">REMUX</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    <span class="movie-card-format">Tamil</span>
                  
                                    <span class="movie-card-format">Telugu</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Toy Story 5</h3>
              <p class="movie-card-meta">2026                            </p>
            </div>
          </a>
          
          
                    
                    <a href="/the-love-hypothesis-movie-8179/" class="movie-card" aria-label="The Love Hypothesis details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/vfZxVHextAGC70zrNhS8lsROqP1.jpg" alt="The Love Hypothesis" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Comedy</span>
                  
                                    <span class="movie-card-format">Romance</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Tamil</span>
                  
                                    <span class="movie-card-format">Movies</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">Amazon Prime Video</span>
                  
                                    <span class="movie-card-format">Telugu</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">The Love Hypothesis</h3>
              <p class="movie-card-meta">2026                            </p>
            </div>
          </a>
          
          
                    
                    <a href="/lanterns-series-7739/" class="movie-card" aria-label="Lanterns details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/original/uAVR8jRsd0VUBC9lHRdEb38oNSa.jpg" alt="Lanterns" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">Action & Adventure</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">HEVC</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">Multi Audios</span>
                  
                                    <span class="movie-card-format">Mystery</span>
                  
                                    <span class="movie-card-format">Sci-Fi & Fantasy</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">Tamil</span>
                  
                                    <span class="movie-card-format">Telugu</span>
                  
                                    <span class="movie-card-format">WEB-DL</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Lanterns</h3>
              <p class="movie-card-meta">2026              • S01 EP06              </p>
            </div>
          </a>
          
          
                    
                    <a href="/the-get-out-movie-8139/" class="movie-card" aria-label="The Get Out details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/zlkeH0s7dDxcnuPcHBqAyXFUxqN.jpg" alt="The Get Out" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Action</span>
                  
                                    <span class="movie-card-format">Thriller</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">HDR</span>
                  
                                    <span class="movie-card-format">AV1</span>
                  
                                    <span class="movie-card-format">Tamil</span>
                  
                                    <span class="movie-card-format">Movies</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">Amazon Prime Video</span>
                  
                                    <span class="movie-card-format">Telugu</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">The Get Out</h3>
              <p class="movie-card-meta">2026                            </p>
            </div>
          </a>
          
          
                    
                    <a href="/the-scandal-series-8138/" class="movie-card" aria-label="The Scandal details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/pJsIzlTjmx07ilwEkl0cglrMVa1.jpg" alt="The Scandal" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Drama</span>
                  
                                    <span class="movie-card-format">History</span>
                  
                                    <span class="movie-card-format">Romance</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">Korean</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">The Scandal</h3>
              <p class="movie-card-meta">2026              • S01              </p>
            </div>
          </a>
          
          
                    
                    <a href="/texas-chainsaw-unrated-movie-8208/" class="movie-card" aria-label="Texas Chainsaw [UNRATED] details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-bd" title="Blu-ray">BD</span></div>              <img src="https://image.tmdb.org/t/p/w500/qn0DdsvVWMXxQtWvdIgvmnYCuJd.jpg" alt="Texas Chainsaw [UNRATED]" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Horror</span>
                  
                                    <span class="movie-card-format">Thriller</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">Dual Language</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">BluRay</span>
                  
                                    <span class="movie-card-format">REMUX</span>
                  
                                    <span class="movie-card-format">Movies</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Texas Chainsaw [UNRATED]</h3>
              <p class="movie-card-meta">2013                            </p>
            </div>
          </a>
          
          
                    
                    <a href="/delusion-series-8185/" class="movie-card" aria-label="Delusion details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/aJboceWct3FYptVPavlhUOjiiSe.jpg" alt="Delusion" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Drama</span>
                  
                                    <span class="movie-card-format">Thriller</span>
                  
                                    <span class="movie-card-format">Crime</span>
                  
                                    <span class="movie-card-format">Mystery</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Netflix</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Delusion</h3>
              <p class="movie-card-meta">2026              • S01              </p>
            </div>
          </a>
          
          
                    
                    <a href="/the-exiled-heavy-knight-knows-how-to-game-the-system-series-7706/" class="movie-card" aria-label="The Exiled Heavy Knight Knows How to Game the System details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-fhd" title="Full HD">FHD</span></div>              <img src="https://image.tmdb.org/t/p/w500/bADzMfofNWYdxLnlqNuMkO6du34.jpg" alt="The Exiled Heavy Knight Knows How to Game the System" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Animation</span>
                  
                                    <span class="movie-card-format">Action & Adventure</span>
                  
                                    <span class="movie-card-format">Sci-Fi & Fantasy</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">Anime</span>
                  
                                    <span class="movie-card-format">Amazon Prime Video</span>
                  
                                    <span class="movie-card-format">Crunchyroll</span>
                  
                                    <span class="movie-card-format">Japanese</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">The Exiled Heavy Knight Knows How to Game the System</h3>
              <p class="movie-card-meta">2026              • S01 EP10              </p>
            </div>
          </a>
          
          
                    
                    <a href="/wwe-smackdown-series-358/" class="movie-card" aria-label="WWE SmackDown details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-fhd" title="Full HD">FHD</span></div>              <img src="https://image.tmdb.org/t/p/original/1WA4RvB4aJ7LY4s9xEw0SkRaS5x.jpg" alt="WWE SmackDown" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Action</span>
                  
                                    <span class="movie-card-format">Reality</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">Netflix</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">60 FPS</span>
                  
                                    <span class="movie-card-format">Live</span>
                  
                                    <span class="movie-card-format">WWE</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">WWE SmackDown</h3>
              <p class="movie-card-meta">2025              • S27-S28 EP39              </p>
            </div>
          </a>
          
          
                    
                    <a href="/fantastic-mr-fox-movie-8207/" class="movie-card" aria-label="Fantastic Mr Fox details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span><span class="quality-badge badge-bd" title="Blu-ray">BD</span></div>              <img src="https://image.tmdb.org/t/p/w500/bOVr292mwn3jxr1e0NmUPM1rcjo.jpg" alt="Fantastic Mr Fox" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Adventure</span>
                  
                                    <span class="movie-card-format">Animation</span>
                  
                                    <span class="movie-card-format">Comedy</span>
                  
                                    <span class="movie-card-format">Family</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">HEVC</span>
                  
                                    <span class="movie-card-format">BluRay</span>
                  
                                    <span class="movie-card-format">REMUX</span>
                  
                                    <span class="movie-card-format">Movies</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">VOD</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Fantastic Mr Fox</h3>
              <p class="movie-card-meta">2009                            </p>
            </div>
          </a>
          
          
                    
                    <a href="/the-elusive-samurai-series-310/" class="movie-card" aria-label="The Elusive Samurai details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-fhd" title="Full HD">FHD</span></div>              <img src="https://image.tmdb.org/t/p/w500/f9ZgHhSwJKkoaVAuYz4uJaHsqii.jpg" alt="The Elusive Samurai" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Animation</span>
                  
                                    <span class="movie-card-format">Action & Adventure</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">DDP</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">Anime</span>
                  
                                    <span class="movie-card-format">Amazon Prime Video</span>
                  
                                    <span class="movie-card-format">Crunchyroll</span>
                  
                                    <span class="movie-card-format">Japanese</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">The Elusive Samurai</h3>
              <p class="movie-card-meta">2024              • S01-S02 EP20              </p>
            </div>
          </a>
          
          
                    
                    <a href="/i-became-a-legend-after-my-10-year-long-last-stand-series-7536/" class="movie-card" aria-label="I Became a Legend After My 10 Year-Long Last Stand details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-fhd" title="Full HD">FHD</span></div>              <img src="https://image.tmdb.org/t/p/w500/4LaPshxWTFcBhc5ib8xOfYeD9tH.jpg" alt="I Became a Legend After My 10 Year-Long Last Stand" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Animation</span>
                  
                                    <span class="movie-card-format">Action & Adventure</span>
                  
                                    <span class="movie-card-format">Sci-Fi & Fantasy</span>
                  
                                    <span class="movie-card-format">Hindi</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">Anime</span>
                  
                                    <span class="movie-card-format">Amazon Prime Video</span>
                  
                                    <span class="movie-card-format">Crunchyroll</span>
                  
                                    <span class="movie-card-format">Japanese</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">I Became a Legend After My 10 Year-Long Last Stand</h3>
              <p class="movie-card-meta">2026              • S01 EP10              </p>
            </div>
          </a>
          
          
                    
                    <a href="/crash-course-in-romance-series-8206/" class="movie-card" aria-label="Crash Course in Romance details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-fhd" title="Full HD">FHD</span></div>              <img src="https://image.tmdb.org/t/p/w500/88rQREli2xtoDV6HToJysp71ZL7.jpg" alt="Crash Course in Romance" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Drama</span>
                  
                                    <span class="movie-card-format">Comedy</span>
                  
                                    <span class="movie-card-format">Romance</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Netflix</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">Korean</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Crash Course in Romance</h3>
              <p class="movie-card-meta">2023              • S01              </p>
            </div>
          </a>
          
          
                    
                    <a href="/stuart-fails-to-save-the-universe-series-7540/" class="movie-card" aria-label="Stuart Fails to Save the Universe details">
            <div class="movie-card-image">
              <div class="quality-badges"><span class="quality-badge badge-4k" title="4K Ultra HD">4K</span><span class="quality-badge badge-dv" title="Dolby Vision">DV</span><span class="quality-badge badge-hdr" title="HDR">HDR</span></div>              <img src="https://image.tmdb.org/t/p/w500/iQbTbwmLX5Nh1nlH21YUJPWt3Zo.jpg" alt="Stuart Fails to Save the Universe" class="w-full h-full object-cover">
              <div class="movie-card-overlay">
                <div class="movie-card-formats">
                  
                                    <span class="movie-card-format">Comedy</span>
                  
                                    <span class="movie-card-format">Sci-Fi & Fantasy</span>
                  
                                    <span class="movie-card-format">English</span>
                  
                                    <span class="movie-card-format">2160p</span>
                  
                                    <span class="movie-card-format">1080p</span>
                  
                                    <span class="movie-card-format">Series</span>
                  
                                    <span class="movie-card-format">10Bit</span>
                  
                                    <span class="movie-card-format">DV HDR</span>
                  
                                    <span class="movie-card-format">Amazon Prime Video</span>
                  
                                    <span class="movie-card-format">HBO Max</span>
                  
                                    <span class="movie-card-format">SDR</span>
                  
                                    <span class="movie-card-format">Crave</span>
                  
                                    </div>
              </div>
            </div>
            <div class="movie-card-content">
              <h3 class="movie-card-title">Stuart Fails to Save the Universe</h3>
              <p class="movie-card-meta">2026              • S01              </p>
            </div>
          </a>
          
          
                    
         
        </div>
      </section>

      <div class="pagination-container">
    <div class="pagination-container">
    <div class="pagination">

        
                
        <a class='pagination-item active'>1</a><a href='/page/2/' class='pagination-item'>2</a><a href='/page/394/' class='pagination-item'>394</a>
        
                <a href="/page/2/" class="pagination-item pagination-next">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4">
                <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
        </a>
            </div>
</div>

</div>

    </div>
  </main>

  <footer class="border-t bg-background">
    <div class="container py-8 md:py-12">
      <div class="grid grid-cols-1 gap-8 md:grid-cols-4 justify-center text-center md:text-left">
        <div class="space-y-4">
          <h3 class="text-lg font-semibold">4KHDHub</h3>
          <p class="text-sm text-muted-foreground">
            Your one-stop destination for high-quality movies and TV shows in various formats.
          </p>
        </div>
        
        <div class="space-y-4">
          <h3 class="text-lg font-semibold">Quick Links</h3>
          <ul class="flex flex-wrap justify-center gap-4 text-sm">
            <li>
              <a href="/about" class="text-muted-foreground hover:text-primary">
                About Us
              </a>
            </li>
            <li>
              <a href="/contact" class="text-muted-foreground hover:text-primary">
                Contact Us
              </a>
            </li>
            <li>
              <a href="/dmca" class="text-muted-foreground hover:text-primary">
                DMCA
              </a>
            </li>
            <li>
              <a href="/privacy-policy" class="text-muted-foreground hover:text-primary">
                Privacy Policy
              </a>
            </li>
          </ul>
        </div>
  
        <div class="space-y-4">
          <h3 class="text-lg font-semibold">Connect</h3>
          <p class="text-sm text-muted-foreground">Stay updated with the latest releases and news.</p>
        </div>
      </div>
  
      <div class="mt-8 border-t pt-8 text-center">
        <p class="text-xs text-muted-foreground">© <span id="current-year">2025</span> 4KHDHub - All rights reserved.</p>
        <p class="text-xs text-muted-foreground mt-2">Made by <a href="https://hdhub4u.download/" target="_blank" class="hover:text-primary">HDHub4U Team</a></p>
      </div>
    </div>
  </footer>

  <button id="back-to-top" class="fixed bottom-6 right-6 z-50 rounded-full shadow-md transition-opacity duration-300 opacity-0 pointer-events-none bg-primary text-primary-foreground p-2" aria-label="Back to top">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m18 15-6-6-6 6" />
    </svg>
  </button>
  </div>
</div>

<script src="/js/main.js?v=0.15.69g27"></script>
<link rel="stylesheet" href="/css/swup.css?v=0.15.69g27.1786779206">
<link rel="stylesheet" href="/css/redisgnv1.css?v=0.15.69g27.1786779206">
<script src="/js/site-interactions.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/redisgnv1.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/vendor/swup.min.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/vendor/progress.min.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/vendor/head.min.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/vendor/scripts.min.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/vendor/preload.min.js?v=0.15.69g27.1786779206" defer></script>
<script src="/js/swup-boot.js?v=0.15.69g27.1786779206" defer></script>


<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v31edd6df95cf4e85bb4c19e7a9bdbcba1788362987495" integrity="sha512-iIg7k2xntmwu6/uSb5tpc/hySgZc4eoL31yB29W6tJFo2akwjPWcEqnCEdJvGexCL0KEQwVYv5BlowfhVz26hg==" data-cf-beacon='{"version":"2024.11.0","token":"efe0ca2393ee48dfb6430bf1697141ee","r":1,"spa":2}' crossorigin="anonymous"></script>
</body>
</html>